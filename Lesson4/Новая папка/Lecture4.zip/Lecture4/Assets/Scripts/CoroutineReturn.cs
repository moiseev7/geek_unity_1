﻿public enum CoroutineReturn
{
    Null,
    WaitForFixedUpdate,
    WaitForEndOfFrame,
    WaitForSecond
}